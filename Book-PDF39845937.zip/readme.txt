Exploiter By Agniane Stealer � 2023
Buy a Agniane stealer: https://t.me/agniane

You can change the icon only for a .lnk file (shortcut)
Exploits of all formats are launched only on Windows!